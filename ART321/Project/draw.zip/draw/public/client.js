// Tutorial from: http://code-and.coffee/post/2015/collaborative-drawing-canvas-node-websocket/

//Client side for node.js drawing application
document.addEventListener("DOMContentLoaded", function() {
   var mouse = {
      click: false,
      move: false,
      pos: {x:0, y:0},
      pos_prev: false
   };
   // get canvas element and create context
   var canvas  = document.getElementById('drawing');
   var context = canvas.getContext('2d');
   var width   = window.innerWidth;
   var height  = window.innerHeight / 2;
   var socket  = io.connect();

   // set canvas to full browser width/height
   canvas.width = width;
   canvas.height = height;

   // register mouse event handlers
   canvas.onmousedown = function(e){ mouse.click = true; };
   canvas.onmouseup = function(e){ mouse.click = false; };

   canvas.onmousemove = function(e) {
      // normalize mouse position to range 0.0 - 1.0
      mouse.pos.x = e.clientX / width;
      mouse.pos.y = e.clientY / height;
      mouse.move = true;
   };

   // draw line received from server
	socket.on('draw_line', function (data) {
      var line = data.line;
      context.beginPath();
      context.moveTo(line[0].x * width, line[0].y * height);
      context.lineTo(line[1].x * width, line[1].y * height);
      context.stroke();
   });

   var socket = io();
   /*
   Emit a message to the server when the user submits
   */
   $('form').submit(function(){
     socket.emit('chat message', $('#m').val());
     // clear the drawing board.
     if ($('#m').val() == "clear")
     {
       context.clearRect(0, 0, width, height);
     }
     $('#m').val('');
     return false;
   });
   /*
   Display messages from other clients that the server broadcasts.
   */
   socket.on('chat message', function(msg){
     $('#messages').append($('<li>').text(msg));
     // clear the drawing board if "clear" is received
     if (msg == "clear")
     {
       context.clearRect(0, 0, width, height);
     }
   });

   // main loop, running every 25ms
   function mainLoop() {
      // check if the user is drawing
      if (mouse.click && mouse.move && mouse.pos_prev) {
         // send line to to the server
         socket.emit('draw_line', { line: [ mouse.pos, mouse.pos_prev ] });
         mouse.move = false;
      }
      mouse.pos_prev = {x: mouse.pos.x, y: mouse.pos.y};
      setTimeout(mainLoop, 25);
   }

   mainLoop();
});
